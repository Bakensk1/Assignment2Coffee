package org.example.decorator;

public interface ICoffee {

    String getDescription();

    double cost();
}